# Exception handling

# A further example about exceptions. The program takes two values volume and
# mass as command line parameters, and prints out the corresponding density.
# Try first normal parameters, such as 4 and 5, and then e.g. 4 and 0. The
# latter values would result in division by zero.
from sys import argv

# A function that computes the density of something. This is called by "a".
# The division operation mass/volume would lead to an error, if volume == 0.
# By default, Python would raise en exception of type ZeroDivisionError. Just
# as an example, we will instead raise an exception of type Exception if
# volume = 0. The type Exception is a "supertype" of all Python exceptions.
def density(mass, volume):
  if volume == 0.0:
    raise Exception("Division by zero")
  return mass/volume

# The function "a" calls density with its parameters m and v.
# If the density function call raises an exception, the code execution will
# first jump from density to this function "a", and then immediately jump out
# of "a" to its caller "b", as "a" does not handle the exception.
def a(m, v):
  return density(m, v)

# The function "b" calls "a" with its parameters m and v. This function also
# handles an exception of type Exception. If v == 0 and thus the call a(m, v)
# calls density with volume 0, the density function will raise an exception of
# type Exception. This function "b" will then be the nearest enclosing point
# that handles Exception and so the code execution would jump from density to
# the "except Exception"-block of this function.
# Once an exception has been caught ("handled"), the exception handler can also
# reraise the exception (if for some reason the same exception requires some
# actions also in some other outer except block). If you uncomment the
# raise statement, the function "b" will reraise the same exception of type
# Exception that was caught by the except-block. The result is that the code
# execution will again start to look for the nearest enclosing handler for
# Exception.
def b(m, v):
    try:
        return a(m, v)
    except Exception as e:
#        print("b caught the exception")
        print(str(e) + " b caught the exception")
#        raise

# The function "c" calls "b" with its parameters m and v.
# If "b" reraises the exception, the code execution will jump from that raise
# statement to this function "c", and then immediately jump out from "c" to its
# caller (the code below directly in the file body) as "c" does not handle the
# exception.
def c(m, v):
    return b(m, v)


# Try to print out the density corresponding to the two command line parameters.
# Just as an example, this is done by calling "c" instead of density directly.
# "c" will then forward the parameters to "b", which will forward them to "a",
# which will finally forward them to density. The code below also handles an
# exception of type Exception that might arise from calling "c" (if the raise
# statement in "b" is uncommented).
# The code below also contains a finally-block, which will always be executed
# regardless of whether any exception was raised or not. Therefore the program
# will print out "Final cleaning up" e.g. both with parameters 4 and 5 as well
# as with parameters 4 and 0.
try:
  #print(c(float(argv[1]), float(argv[2])))
    print(c(4, 0))
except Exception as e:
    print(e)
finally:
    print("Final cleaning up")

print("The end")