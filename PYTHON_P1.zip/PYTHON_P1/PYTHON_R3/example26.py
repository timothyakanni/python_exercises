
from sys import argv

with open(argv[1]) as infile:
    for line in infile:
        if line.startswith("Degree programme"):
            print(line)

with open(argv[1]) as infile:
    for line in infile:
        try:
            line.index("vastuuhenkilo")
            print(line)
        except:
            pass


with open(argv[1]) as infile:
    for line in infile:
        if(line.find("vastuuhenkilo") != -1):
            print(line)

# Regular Expression
#import re module

import re
with open(argv[1]) as infile:
    for line in infile:
        res = re.search(r"[\w.]+@[\w]+[.]", line)
        if res:
            print("match: ", res.span(), line[res.start() : res.end()] )


with open(argv[1]) as infile:
    for line in infile:
        res = re.search(r"[\w.]+@[\w]+[.]", line)
        if res:
            print("match: ", res.span(), line[res.start() : res.end()] )