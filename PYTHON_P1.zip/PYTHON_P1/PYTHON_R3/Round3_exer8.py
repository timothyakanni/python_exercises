# DNA Sequence 2 --- Done

import re
import sys


def listSeqs(typeStr, filename):
    with open(filename) as infile:
        text = infile.read()
    pattern = typeStr + (r'\s+(complement\(join\(|join\(|complement\()' +
                         r'(\d+\.\.\d+(,\s*\d+\.\.\d+)*)\)')
    reg = re.compile(pattern)
    m = reg.search(text)
    while m:
        if m.group(1).startswith("complement"):
            print("Complemented interval(s):")
        else:
            print("Interval(s):")
        ints = re.split(r"[\D]+", m.group(2))
        for i in range(0, len(ints), 2):
            print(" ", ints[i], "-->", ints[i + 1])
        m = reg.search(text, m.end())
