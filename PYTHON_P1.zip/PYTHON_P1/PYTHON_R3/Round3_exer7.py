# Course --- Done (Finished by teacher)

#pattern = re.compile(r'([A-Z]+[0-9]+(\s\/\s[A-Z]+[0-9]+)?)\s(\D+(\d{4}\))?' +
#                     r'(\d{4})?)\s(\d(\S\d*)*)\s[A-Z]{4}') # has groups

class Course:
    def __init__(self, code, name, minCredits, maxCredits):
        self.code = str(code)
        self.name = str(name)
        self.minCredits = int(minCredits)
        self.maxCredits = int(maxCredits)

    def __str__(self):

        if self.minCredits == self.maxCredits:
            return "" +self.code +" "+ self.name + " "+str(self.minCredits) + "ECTS"
        else:
            return "" + self.code + " " + self.name + " " + \
                   str(self.minCredits) + "-" + str(self.maxCredits) + "ECTS"

    def __eq__(self, other):
        return self.name == other.name

    def __hash__(self):
        return self.name.__hash__()

def readCourses(filename):
    courseList = []
    with open(filename) as infile:
        for line in infile:
            pass


    return courseList