# This is about inheritance

from sys import argv

class VolumeZeroException(Exception):
    pass

