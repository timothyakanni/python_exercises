#This is about working with exception
from sys import argv


def density(mass, volume):
    if volume == 0.0:
        raise Exception("Division by zero")
    return mass/volume

def a(m, v):
    return density(m, v)


def b(m, v):
    try:
        return a(m, v)
    except Exception:
        print("b caught the exception")
#        raise

def c(m, v):
    return b(m, v)

try:
    print(c(float(5),float(0)))
except Exception as e:
    print(e)
#this part get executed either way(ifthereis or not exception)
finally:
    print("Cleaning up")
#print(density(float(argv[1]),float(argv[2])))

