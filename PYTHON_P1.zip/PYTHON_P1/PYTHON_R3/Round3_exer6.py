# Currency Rate 2 ---Done (Teacher)

from sys import argv
import re


pattern = r'[^\t]+\t([^\t]+)\t([\d.]+)\t[\d.]+'

def replacementFunction(match):
  return match.group(1) + " = " + str(round(float(match.group(2)), 4))

with open("currencies.txt", encoding="utf-8") as infile:
  for line in infile:
    print(re.sub(pattern, replacementFunction, line).strip())


# LSL	Basotho Loti	16.1658198594	0.0618589103
# SAR	Saudi Arabian Riyal	4.4018470070	0.2271773640
# MZN	Mozambican Metical	71.6691665483	0.0139530017
# SRD	Surinamese Dollar	8.6607427023	0.1154635387
# SCR	Seychellois Rupee	15.9277900555	0.0627833489
# QAR	Qatari Riyal	4.3523387962	0.2297615252
# PHP	Philippine Peso	60.0427242272	0.0166548073
# BND	Bruneian Dollar	1.6048709843	0.6231030468
# MYR	Malaysian Ringgit	4.9746576571	0.2010188578
# GEL	Georgian Lari	2.9025951704	0.3445192806
