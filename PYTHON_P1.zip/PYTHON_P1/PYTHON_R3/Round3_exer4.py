# Currency rates ---Done

class Currency:
    def __init__(self, name, fullName, euroRate):
        self.name = name
        self.fullName = fullName
        self.euroRate = float(euroRate)


def loadCurrencies(filename):
    currencies = {}
    with open(filename, encoding="utf-8") as infile:
        for line in infile:
            res = line.split("\t")
            currency = Currency(res[0], res[1], res[3])
            currencies[res[0]] = currency

        return currencies

# this condition in the if means is used to avoid execution of
# this part of the code in other files where this code file is
# used as module. Other files that import this code file can only have
# access to the class Currency and loadCurrencies def. check
#  and run main.py, there this file is imported.
if (__name__ == "__main__"):
    d = []
    for key_value in sorted(loadCurrencies("currencies.txt").items()):
        d.append(key_value[1].fullName)

    for i in sorted(d):
        print(i)

