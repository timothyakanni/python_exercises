# Another basic example of using classes. This example defines some
# classes that might be used in some type of an internet shop. There are
# three classes: Product, ShoppingCart and Inventory. Product is used for
# representing products, and each product has a product code, name and price.
# ShoppingCart is used for maintaining a list of products together with their
# total price. Inventory is used for maintaining a dictionary of products,
# where product code is the key and a corresponding Product-object is the
# value. Inventory could maintain information about all products that are
# available in the shop.
#
# The example is quite rudimentary and has only very basic functionality. But
# it should nevertheless give some further understanding of how one might use
# Python classes.

import re

# Product is the simplest of these classes. It only stores code, name and price
# and does not offer any other functionality than the initialization function.
class Product:
  def __init__(self, code, name, price):
    self.code = code
    self.name = name
    self.price = price

# ShoppingCart contains an initialization function that initializes an empty
# shopping cart, and an add function that adds products into the cart.
class ShoppingCart:
  def __init__(self):
    self.products = []
    self.totalPrice = 0.0

  # The add function allows to give an arbitrary number of parameters: this
  # is achieved by inserting the special *-prefix in front of the parameter
  # name: this turns that parameter into a list that will be populated with
  # all excess parameters given when the function was called. Here by "excess
  # parameters" we mean parameters that did not correspond to any other
  # (e.g. "normal") parameter. As this function does not take any other
  # parameters from the caller (self is supplied by Python), all its parameters
  # will be in the list productList. E.g. the call add(1, 2, 3) would result in
  # productList of form [1, 2, 3], and the call add("a string") to productList
  # of form ["a string"].
  #
  # This add function implementation assumes that all parameters are Product-
  # objects and adds them into the products-list, also updating the total
  # price.
  def add(self, *productList):
    for product in productList:
      self.products.append(product)
      self.totalPrice += product.price

# Inventory contains an initialization function that initializes an empty
# product dictionary. It also has the function populateInventory, which reads
# product information from a file and creates and inserts corresponding
# Product-objects into the product dictionary. The product file is assumed
# to be like the provided example data file inventory.txt.
# As last, Inventory also contains a function getProduct that retrieves
# a Product-object from the product dictionary based on product code.
class Inventory:
  def __init__(self):
    self.products = {}

  def populateInventory(self, filename):
    with open(filename) as infile:
      for line in infile:
        # The value columns are separated by tabulators, so do split("\t").
        parts = line.split("\t")
        code = parts[0]
        name = parts[2]
        # The price contains some extra characters (a dollar sign and maybe
        # some extra dots etc.). We remove the extra characters with re.sub.
        # Here the matcing expression [^\d,] is a character class that matches
        # any character that is not a digit or a comma (the first ^ specifies
        # that the character class matches anything but the following types
        # of characters). As last the comma in the price is converted into a
        # dot so that Python's float conversion does not give an error.
        price = float(re.sub(r"[^\d,]", "", parts[5]).replace(",", "."))
        self.products[code] = Product(code, name, price)

  # Simply return the Product-object corresponding to the code parameter.
  # This could be more intelligent; this implementation simply raises a
  # KeyError if the product dictionary does not contain a product
  # whose key is code.
  def getProduct(self, code):
    return self.products[code]

# A small test. First create an Inventory-object and populate it from
# inventory.txt.
inv = Inventory()
inv.populateInventory("inventory.txt")

# Now check what we could read in. This prints out all the product codes
# (= the keys of the product dictionary). We use here the *-operator to unpack
# the key-list products.keys() into separate parameters.
print(*inv.products.keys())

# Now let's create a ShoppingCart and add some products into it. The added
# product is retrieved from the inventory using getProduct.
cart = ShoppingCart()
cart.add(inv.getProduct("99-9492001"))
# One product added: let's check the price.
print("Total price:", cart.totalPrice)

# Now let's buy everything the store has to offer: add all products in the
# inventory into the shopping cart. We use here the *-operator to unpack
# the object-list products.values() into separate parameters.
cart.add(*inv.products.values())
print("Total price:", cart.totalPrice)

# Finally also verify that we can give multiple parameters also in the "normal"
# way. Here we add three Product-objects.
cart.add(inv.getProduct("99-9492001"), inv.getProduct("99-97210000"),
         inv.getProduct("99-0921305"))
print("Total price:", cart.totalPrice)