# Name switch ---Done (Teacher)

from sys import argv
import re

# Initially pattern and replacement are empty raw strings

# Set below suitable expressions to pattern and replacement
#pattern = r'(^\w+)\s([^\s/]+(\s|-|\.|)?[^\s/]+)'
#pattern = r'(^\w+)([^\/]+)'
pattern = r'^["]([^\s/]+) ((\s*[^\s/]+)+)' #teacher solution
#pattern = re.compile(pattern)
replacement = r'\2 \1'

# Set above suitable expressions to pattern and replacement
with open("tulokset.csv") as infile:
  for line in infile:
      print(re.sub(pattern, replacement, line).strip())

