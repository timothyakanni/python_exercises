#This is about SET manipulation

#set is in not in particular order
setA = {x for x in range(0, 100, 5)}
setB = {x for x in range(0, 150, 10)}
print(setA, setB)

#union of setA and setB
setAB = setA | setB
print(setAB)

#intersection of setA and setB
setAandB = setA & setB
print(setAandB)

#this removes items of setB in setA
setOnlyA = setA - setB
print(setOnlyA)


