# Here is lecture about class

class Country:
    # this is similar to constructor
    def __init__(self, name, population, area):
        self.name = name
        self.population = population
        self.area = area

    def __str__(self):
        return "<" + self.name + "," + self.population + "," + self.area + ">"

    def __eq__(self, other):
        return self.name == other.name

    def __ne__(self, other):
        return self.anme != other.name

    def __lt__(self, other):
        return self.name < other.name

    def __gt__(self, other):
        return self.name > other.name

    def __hash__(self):
        return self.name.__hash__
