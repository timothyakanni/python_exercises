#Sudoku with Exception --- Done


def printSudoku(parameter):

    if type(parameter) != str:
        msg = "Illegal Sudoku type" + " " + str(type(parameter))
        raise TypeError(msg)
    if len(parameter) != 81:
        msg = "Illegal Sudoku length" + " " + str(len(parameter)) + " != 81"
        raise ValueError(msg)
    if (type(parameter) == str and len(parameter) == 81):
            for x in parameter:
                if x not in ["1", "2", "3", "4", "5", "6", "7", "8", "9"]:
                    msg = "The value " + str(x) + " is not a legal Sudoku digit"
                    raise ValueError(msg)
                else:
                    pass
    if (type(parameter) == str and len(parameter) == 81):
        ch_list = []
        for ch in parameter:
            ch_list.append(ch)

        for k in range(3):  # created first structure and duplicate 3 times
            for i in range(37): #i first line of # only
                 print("#", end="")
            print("")
            for m in range(5): # duplicate second line in code below 5 times
                for j in range(37): # created second line and use range of 5 above to dupliace 5 times
                    if (j%12 == 0):
                        print("#", end="")
                    elif(j%4 == 0 and m%2 == 0):
                        print("|", end="")
                    elif(j%4 == 0 and m%2 != 0):
                        print("+", end="")
                    elif (m % 2 != 0):
                        print("-", end="")
                    elif (j%2 == 0):
                            # put the first character in the ch_list and remove the
                            # character from the list
                            print(ch_list[0], end="")
                            del ch_list[0]
                    else:
                        print(" ", end="")
                print("")

        for i in range(37): # last line of # only
            print("#", end="")



parameter = "893957416984821599901694287486295939c39768128217349865762583941345192678198476359"

try:
    printSudoku(parameter)
except TypeError as e:
  print("TypeError:", e)
except ValueError as e:
  print("ValueError:", e)

print()
