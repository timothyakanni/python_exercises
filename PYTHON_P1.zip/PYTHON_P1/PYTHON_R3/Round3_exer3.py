# Jaccard Similarity ---Done (Teacher)
# wordsA = []
# wordsB = []
# with open(argv[2]) as fileA, open(argv[3]) as fileB:
#   wordsA = fileA.read().split()
#   wordsB = fileB.read().split()
#
# setA = set()
# for i in range(k-1, len(wordsA)):
#   setA.add(tuple(wordsA[i-k+1 : i+1]))
# setB = set()
# for i in range(k-1, len(wordsB)):
#   setB.add(tuple(wordsB[i-k+1 : i+1]))
#
# jac = len(setA & setB) / len(setA | setB)
# print("JAC(" + str(k) + "):", round(jac, 4))

def jaccardSimilarity(k, a, b):
    wordsA = []
    wordsB = []
    # list of words in a and b
    with open(a) as infile:
        wordsA = infile.read().split()

    with open(b) as infile:
        wordsB = infile.read().split()

    print(wordsA)
    print()
    setA = set()
    for i in range(k-1, len(wordsA)):
        setA.add(tuple(wordsA[i-k+1 : i+1]))
    print(setA)
    setB = set()
    for i in range(k-1, len(wordsB)):
        setB.add(tuple(wordsB[i-k+1 : i+1]))

    result = len(setA & setB)/ len(setA | setB)

    print("JAC(" + str(k) + "): " + str(round(result, 4)))
    print()

jaccardSimilarity(3, "a.txt", "b.txt")
