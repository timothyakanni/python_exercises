# Raising Exceptions ---Done

def doSomething(par):
    try:
        print("par:", par)
        print(" length:", len(par), end="")
        print(" Value at index 5:", par[5], end="")
        print(" As an integer:", int(par), end="")


    except Exception as e1:
        if type(e1) == ValueError:
            raise ValueError("Value: "+str(e1))
        if type(e1) == TypeError:
            raise TypeError("TypeError: " + str(e1))
        if type(e1) == IndexError:
            raise IndexError("IndexError: " + str(e1))
        if type(e1) == KeyError:
            raise KeyError("KeyError: " + str(e1))

    finally:
        print()

for par in ["a string", 3.14, [1, 2, 3, 4], {}]:
    try:
        doSomething(par)
    except Exception as e:
        print(str(type(e)) + "\n", str(e))

print()
# Add your new doSomething(par) below
