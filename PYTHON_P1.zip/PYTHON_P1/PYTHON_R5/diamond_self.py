
h = input()
while h:
    h = int(h)
    n = int(input())
    s = input()

    side = h//2
    middle = -1

    for row in range(h):
        for num in range(n):

            print(" " * side + s, end="")

            if(middle > 0):
                print(" " * middle + s, end="")
            print(" " * (side + 1 if num < n-1 else side), end="")

        print()
        if(row < h // 2):
            side -= 1
            middle += 2
        else:
            side += 1
            middle -= 2
    print()
    h = input()
