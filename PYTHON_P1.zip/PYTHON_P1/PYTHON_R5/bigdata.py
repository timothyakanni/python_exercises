import re

pattern = re.compile(r'(\d+\.\d+)(\,[^d])')
# for lattitude (\d+\.\d+)(\})
# for longitude (\d+\.\d+)(\,[^d])
with open("train_station_file.txt") as infile:
    for line in infile:
        print(line)
        max = 0.0
        for d in line.split("}"):
            res = pattern.search(d)
            if res:
                print(res.group(1))
                if float(res.group(1)) > max:
                    max = float(res.group(1))
        print("max", max)
