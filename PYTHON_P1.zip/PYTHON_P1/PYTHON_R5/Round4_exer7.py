# Document - term matrix ---

import pathlib
from sys import argv
import csv
#This is current directory

def document_term(param):

    curr_dir = pathlib.Path(".")
    common_words_list = [""]
    for filename in sorted(curr_dir.glob("*.txt")):
        #print(filename)
        with open(str(filename)) as infile:
            for line in infile:
                for word in line.split(" "):
                    if word.strip("\n") not in common_words_list:
                        common_words_list.append(word.strip("\n"))

    print(sorted(common_words_list))
    print(len(sorted(common_words_list)))
    print(",".join(sorted(common_words_list)))

    # Opt start
    with open(param, "w") as outfile:
        csvwr = csv.writer(outfile, delimiter=",")
        csvwr.writerow(sorted(common_words_list))

        for filename in sorted(curr_dir.glob("*txt")):
            result_row = []
            result_row.append(str(filename))
            file_word_list = []
            with open(str(filename)) as infile:
                for line in infile:
                    for word in line.split(" "):
                        file_word_list.append(word.strip("\n"))

            for i in range(1, len(sorted(common_words_list))):
                count_ = 0
                for j in range(0, len(file_word_list)):
                    if (sorted(common_words_list)[i] == file_word_list[j]):
                        count_ = count_ + 1

                result_row.append(count_)
            print(*result_row)
            csvwr.writerow(result_row)
            # Opt end


import timeit
start = timeit.default_timer()
document_term("docterms.csv")
finish = timeit.default_timer()
print(finish-start)

# before optimization
# time is 0.6308282207850892
