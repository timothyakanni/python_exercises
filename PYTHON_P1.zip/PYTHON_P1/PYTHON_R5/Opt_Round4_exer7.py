# Document - term matrix ---

import pathlib
from collections import Counter
from sys import argv
import csv
#This is current directory

def document_term(param):

    curr_dir = pathlib.Path(".")
    common_words_set = set()
    common_words_set.add("")
    filenames = []
    countMap = {}
    for filename in sorted(curr_dir.glob("*.txt")):
        #print(filename)
        with open(filename.name) as infile:
            word = infile.read().split() # word here is a list of words

            countMap[filename.name] = Counter(word)
            common_words_set.update(word)
            filenames.append(filename.name)

    sortedWords = sorted(common_words_set)
    print(sortedWords)

    print(countMap)
    print()

    # Opt start: Basically trying to avoid for loop as much as possible in ore
    # to optimize the running of the code

    with open(param, "w") as outfile:
        csvwr = csv.writer(outfile, delimiter=",")
        csvwr.writerow([""] + sortedWords)

        for filename in sorted(filenames):
            # writing to cvs file
            result_row = [filename] + [countMap[filename][w] for w in sortedWords]
            csvwr.writerow(result_row)
            # output by printing
            print(filename, end= " ")
            for w in sortedWords:
                print(countMap[filename][w], end=" ")
            print()

    # Opt end

# first.txt,1,0,1,1,1,1,0
# second.txt,0,1,0,1,2,1,1

import timeit
start = timeit.default_timer()
document_term("docterms.csv")
finish = timeit.default_timer()
print(finish-start)

# before optimization
# time is 0.6308282207850892
# after optimization
# time is 0.47033791662115143
