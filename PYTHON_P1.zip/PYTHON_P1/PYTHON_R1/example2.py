## How to make user keep input value until he input quit input
line = input("Give a number or 'quit' or 'reset' : ")
total = 0.0
while(line != "quit"):

    if(line == "reset"):
        total = 0.0
        print("The total was reset to 0.0")

    else:
        number = float(line)
        total += number
    line = input("Give a number or 'quit' or 'reset': ")
else:
    print("The quit command is recieved, stopping....")
## the block os else for while is used when the condition in while loop
## is fulfilled
print("The total is: ", total)

##