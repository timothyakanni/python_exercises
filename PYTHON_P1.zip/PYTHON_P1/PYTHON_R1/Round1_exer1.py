#Hypotenuse of a right triangle ---Done

a = float(input())
b = float(input())
c = (a**2 + b**2)**0.5
print("The hypotenuse of a right triangle with sides " + str(a) + " and " + str(b) +
      " has length " + str((round(c, 3))))



# "The hypotenuse of a right triangle with sides a and b has length c",
# where the result c is printed with 3 decimals of precision.

