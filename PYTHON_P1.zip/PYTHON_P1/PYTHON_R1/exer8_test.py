# We want 2 of this in a row
count = 1

#first test that uses the input r = 4, c = 4, h = 3 and w = 4

for j in range(1,17):
    count = count + 1
    for i in range(1,9):
        print("#",end="")
        if(i%4 == 0):
            print("$$$$", end="")
    if(j%4 == 0):
        print()

    print()




print("")
