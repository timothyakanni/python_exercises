# Prime Numbers

n = int(input())
k = int(input())

count = 0
first = []
result = []
for num in range(2, n+1):
   for i in range(2, num):
       if (num % i) == 0:
           break
   else:
        first.append(num,)
        if (count % k == 0):
            result.append(num,)
        count = count + 1

# The * is used to print avoid print list as list
# but rather print the values in the list without []
# and sep is used to replace the comma delimiter and
# change it to empty space.
print(*result, sep=" ")
print(*first, sep=" ")
