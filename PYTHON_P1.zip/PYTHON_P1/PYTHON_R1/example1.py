x = 10
print(x)

a = 3.0
b= 4.0
c= 5.0

## Way of printing
print("The hypothenus of a right with side %0.1f and %0.1f "
      "has length of %0.2f"%(a,b,c))

## Checking the exercise questions
## For standard input prompt use input()
line = input()
print(type(line))
print("The input line was", line)

year = int(line)
print("The next year is:", year + 1)




