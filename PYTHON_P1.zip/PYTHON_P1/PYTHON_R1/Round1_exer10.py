a = int(input())
b = int(input())
c = int(input())
d = int(input())

print(" "*len(str(b*d)), end=" ")
for v in range(a, b+1):

    print(str(v).rjust(len(str(b*d))+1), end="")
print()
for x in range(c, d+1):
    print(str(x).rjust(len(str(b*d))+1), end="")
    for y in range(a, b+1):
        print(str(x*y).rjust(len(str(b*d))+1), end = "")
    print()


#a = 1, b = 10, c = 11 and d = 20
# a = 81, b = 90, c = 181 and d = 190.

