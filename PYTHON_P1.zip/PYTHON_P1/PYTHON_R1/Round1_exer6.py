# Cartesian Product ---Done

a = int(input())
b = int(input())
c = int(input())
d = int(input())

# here we used increment step of 1
if(a < b and c < d):
    # this is the row movement
    for x in range(a, b+1):
        # this is the column movement
        for y in range(c, d+1):
            print("("+ str(x), " " + str(y) + ")", sep= ",", end = "")
        print()

# here we used decrement step by -1
if(a > b) and (c > d):
    # this is the row movement
    for x in range(a, b-1, -1):
        # this is the column movement
        for y in range(c, d-1, -1):
            print("("+ str(x) + ", " + str(y) + ")" ,end="")
        print()

#a = -1, b = 2, c = 3 and d = 7
#a = 2, b = -1, c = 7 and d = 3