# Leap year checker

line = input()
while (line != ""):
    leap = int(line)
    if(leap % 4 == 0 and (leap % 100 != 0 or leap % 400 == 0)):
        print("The year " + str(leap) + " is a leap year..")
    else:
        print("The year " + str(leap) + " is not a leap year..")

    line = input()
# Here the input has ended. Now it is time to compute and print results.