# Diamond ---Done
#

# Teacher solution
h = input()
while h:
  h = int(h)    # h = 7
  s = input()
  side = (h-1) // 2     #side = 3
  mid = -1
  for row in range(h):
    print(" " * side + s, end="")

    if mid > 0:
      print(" " * mid + s, end="")
    print(" " * side)

    if row < h // 2:    # row < 3
      side -= 1
      mid += 2
    else:
      side += 1
      mid -= 2
  print()
  h = input()

print(" " * 3 + "$", end ="")