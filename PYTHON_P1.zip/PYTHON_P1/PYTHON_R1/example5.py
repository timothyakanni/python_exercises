for i in range(10):
    print(i, end="")
print()

print(1,2,3,4,5,6,7 ,sep = "->")