# Quadratic formula --- Done

a = float(input())
b = float(input())
c = float(input())

s1 = (-b - (b**2 - 4*a*c)**(0.5))/(2*a)

s2 = (-b + (b**2 - 4*a*c)**(0.5))/(2*a)

# "1", "-0.5" and "-1.5"
if(s1 == s2):
    print("One distinct real solution")

    if(b < 0):
        print("The equation " + str(a) + "x^2 - " + str(abs(b)) + "x " + " " + str(c) + " = 0 "
              + "has one distinct real solution: x = " + str(s1))

    if(c < 0):
        print("The equation " + str(a) + "x^2 + " + str(b) + "x - " + str(abs(c)) + " = 0 "
              + "has one distinct real solution: x = " + str(int(s1)))

    if(b < 0 and c < 0):
        print("The equation " + str(a) + "x^2 - " + str(b) + "x " + "- " + str(c) + " = 0 "
              + "has one distinct real solution: x = " + str(s1))

elif(s1 != s2 and (isinstance(s1, complex) == False or isinstance(s2, complex) == False)):
    print("Two different real solution")

    if (a == 1 and b < 0 and c < 0):
        print("The equation x^2 - " + str(abs(b)) + "x " + " - " + str(abs(c)) + " = 0 "
              + "has two distinct real solution: x = " + str(int(s1)) + " and x = " + str(s2))
    if(b < 0 and a != 1):
        print("The equation " + str(a) + "x^2 - " + str(abs(b)) + "x " + "+ " + str(c) + " = 0 "
              + "has two distinct real solutions: x = " + str(round(s1,3)) + " and x = " + str(round(s2,3)))

elif(isinstance(s1, complex) or isinstance(s2, complex)):
    print("The equation " + str(int(a)) + "x^2 + " + str(int(c)) +
          " = 0 has no real solution!")
print(s1)
print(s2)

# Teacher solution

# a = float(input())
# b = float(input())
# c = float(input())
# d = b*b - 4*a*c
# a = int(a) if a == int(a) else a
# b = int(b) if b == int(b) else b
# c = int(c) if c == int(c) else c
# sa = "x^2 " if a == 1 else ("" if a == 0 else (str(a) + "x^2 "))
# p1 = "+ " if b > 0 else ("" if b == 0 else ("- " if sa else "-"))
# sb = "x " if b == 1 else ("" if b == 0 else (str(abs(b)) + "x "))
# p2 = "+ " if c > 0 else ("" if c == 0 else "- ")
# sc = "" if c == 0 else (str(abs(c)) + " ")
# if d < 0:
#   solText = " has no real solution!"
# elif d == 0:
#   x = -b/(2*a)
#   x = int(x) if x == int(x) else x
#   solText = " has one distinct real solution: x = " + str(round(x, 3))
# else:
#   x1 = (-b + (d ** 0.5))/(2*a)
#   x1 = int(x1) if x1 == int(x1) else round(x1, 3)
#   x2 = (-b - (d ** 0.5))/(2*a)
#   x2 = int(x2) if x2 == int(x2) else round(x2, 3)
#   solText = (" has two distinct real solutions: x = " + str(min(x1,x2))
#              + " and x = " + str(max(x1, x2)))
# print("The equation " + sa + p1 + sb + p2 + sc + "= 0" + solText)

