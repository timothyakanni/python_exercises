## practice on for loop

## in java for(int i = 0; i< 10 ; i++)

for i in range(10, 0, -1):
    print("i: ", i)


s = "example string"
print(s[8:3:-1])

lst = [1,2,"hello",4,5,6]
for i in range(len(lst)):
    print(lst[i])
    lst[i] *= 3

lst.append("add")
print(lst)

#Cummulative sum
intlist = [0] * 30
print(intlist)
for i in range(1, len(intlist)):
    intlist[i] = i + intlist[i-1]
print(intlist)

intlist2 = []
print(intlist2)
for i in range(30):
    intlist2.append(0 if i== 0 else i + intlist2[i-1])
print(intlist2)

s = "some string"
slist = list(s)
print(slist)
slist[3] = "X"
print(slist)

s2 = "".join(slist)
print(s2)


userinput = "2 3 4 5 6 7"
print(userinput.split())
total = 0
for sval in userinput.split():
    ival = int(sval)
    total += ival
print("Sum: ", total)



