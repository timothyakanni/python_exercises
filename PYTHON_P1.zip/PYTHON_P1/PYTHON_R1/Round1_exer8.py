# This is about checker pattern

r = int(input("Enter row:"))
c = int(input("Enter column:"))
h = int(input("Enter height:"))
w = int(input("Enter width:"))

print("The teacher solution start here")
print()
# teacher solution1

for row in range(r):
    for i in range(h):
        isWhite = True if (row%2) == 0 else False
        for col in range(c):
            for j in range(w):
                print(" " if isWhite else "#" ,end="")
            isWhite = not isWhite
        print()

