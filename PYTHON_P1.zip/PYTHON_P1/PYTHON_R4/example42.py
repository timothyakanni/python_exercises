# This is about json

import json

string = "python programming"

from collections import Counter
counts = Counter(string)
print(counts)

print()

countDict = dict(counts)
countDict["string"] = list("python programming")
print(countDict)

print()
print(json.dumps(countDict, indent=4))

# we re storing dictionary as json file
js = json.dumps(countDict, sort_keys=True, indent=4, separators=(',', ': '))
with open('your_json_file', 'w') as f:
    f.write(js)

# we re reading from json file
with open("data.json") as infile:
    data = json.load(infile)

print(json.dumps(data, indent= 6))
print(type(data), end="\n\n")


for key in data:
  print(key)

for key in data["widget"]:
    print(key)

print()
print("The image hoffset:", data["widget"]["image"]["hOffset"])
print(type(data["widget"]["image"]["hOffset"]))

data["widget"]["image"]["hOffset"] = 1000

# Here we convert json to string
strJson = json.dumps(data)
print(strJson, end="\n\n")


