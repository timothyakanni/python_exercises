# CSV to JSON ---Done
import json
import csv
from sys import argv

def csv2JSON(inputFile, outputFile):

    resultList = []
    # Reading of CVS file
    with open(inputFile) as infile:
        csvrd = csv.reader(infile, delimiter=";")
        for line in csvrd:
            data = {}
            data["name"] = line[0].split(" / ")[0]
            data["party"] = line[0].split(" / ")[1]
            data["district"] = line[0].split(" / ")[2]
            data["votes"] = int(line[1])
            data["quotient"] = float(line[2])
            resultList.append(data)

    # Writring of resultD from CSV reading
    # into json file
    # we re storing list/Dictionary as json file
    js = json.dumps(resultList, sort_keys=True, indent=3, separators=(',', ': '))
    with open(outputFile, 'w') as f:
        f.write(js)

csv2JSON("results.csv", "results.json")
