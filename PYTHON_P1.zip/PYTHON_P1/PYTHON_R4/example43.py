# Inpsection directory file and reading
# and writing zip files

import pathlib
import zipfile

# This part is reading zip files in current directory

#This is currnt directory
p = pathlib.Path(".")

# This print all the files in the current directory
for filename in p.iterdir():
  print(filename)
print()

for filename in p.glob("*.zip"):
    # This print all the zip files in current directory
    print("The content of ", filename)

    with zipfile.ZipFile(filename.name) as zf:
        for zi in zf.infolist():
            # Let's print out the filename and size.
            print(" ", zi.filename, "(size:", str(zi.file_size) + ")")

            with zf.open(zi) as infile:
                for line in infile:
                    print(str(line, "utf-8"), end="")
        print()

# This part is about writing into zip files which creating zip file and
# putting files into it

with zipfile.ZipFile("newzipfile.zip", "w") as zf:
  # Iterate over the files of form example3*.py.
  for filename in p.glob("example3*.py"):
    # Add the current file to the zip file.
    zf.write(filename.name)
