import csv

# Reading csv file

with open("vaaliliitot.csv", encoding="latin1") as infile:
  # Now let's create a csv.reader-object that reads csv data with column
  # separator ";". The first parameter is the file, and the column separator
  # can be given as a named parameter "delimiter".
  csvrd = csv.reader(infile, delimiter=";")
  # The csv.reader-object can be iterated: each iteration will return the
  # contents of one csv-row as a list: the list contains the values in
  # separate columns. Below we print out each returned list as such,
  # and in addition also print the value in the second column (whose index is 1)
  # if the row contained at least two separate columns.
  for line in csvrd:
    print(line)
    if len(line) > 1:
      print(line[1])

# Writing csv file

with open("output.csv", "w") as outfile:
    csvwr = csv.writer(outfile, delimiter=";")
    csvwr.writerow([0, 'string;with;some;semicolons"and"quotes"', 3, 3.14])
    csvwr.writerow([0, 'string;with;some;semicolons"and"quotes"', 3, 3.14])

# Finally, let's try to read the csv row written above.
with open("output.csv") as infile:
  csvrd = csv.reader(infile, delimiter=";")
  for line in csvrd:
    print(line)