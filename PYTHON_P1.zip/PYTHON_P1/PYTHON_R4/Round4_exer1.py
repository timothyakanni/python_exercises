#Date conversions --- Done
import datetime

date_data = []
with open("datesin.txt") as infile:
    for line in infile:
        for words in line.split():
            try:
                dat = datetime.datetime.strptime(words, "%Y/%m/%d")
                date_data.append(dat)
            except Exception as e:
                if type(e) == ValueError:
                    pass

for dt in sorted(date_data):
    print(dt.strftime("%A, %B %d, %Y"))


#Monday, March 24, 1980