# Zip file information ---Done
import pathlib
from pathlib import PurePath
import zipfile


def zipInformation(*parameter):
    #This is currnt directory
    p = pathlib.Path(".")
    if(len(parameter) == 0):
        for filename in sorted(p.glob("*zip")):
            print(filename.name)
            sum_original_size = 0
            sum_compress_size = 0
            zf_size = pathlib.Path(filename)
            with zipfile.ZipFile(filename.name) as zf:
                for zi in zf.infolist():
                    print("    " + zi.filename + "(size:" + str(zi.file_size) +
                          ", compressed size:" + str(zi.compress_size) +
                          ", compression %: " + str(round(100 * (zi.compress_size) / (zi.file_size), 1)) + "%)")
                    sum_original_size += zi.file_size
                    sum_compress_size += zi.compress_size
                print("  " + "original total size: " + str(sum_original_size))
                print("  " + "sum of compressed sizes: " + str(sum_compress_size))
                print("  " + "zip file size: " + str(zf_size.stat().st_size))
                print("  " + "compression %: " + str(round(100 * (sum_original_size)/(zf_size.stat().st_size), 1)) + " %")
                print("  " + "overhead: " + str((zf_size.stat().st_size) - (sum_compress_size)))
                print()
    else:
        for filename in sorted(p.glob("*zip")):
            for param in (parameter):
                if(PurePath(filename.name).match(param)):
                    print(filename.name)
                    sum_original_size = 0
                    sum_compress_size = 0
                    zf_size = pathlib.Path(param)
                    with zipfile.ZipFile(filename.name) as zf:
                        for zi in zf.infolist():
                            print("    " + zi.filename +"(size:" + str(zi.file_size) +
                            ", compressed size:" +  str(zi.compress_size) +
                            ", compression %: " + str( round(100*(zi.compress_size)/(zi.file_size), 1)) + "%)")
                            sum_original_size += zi.file_size
                            sum_compress_size += zi.compress_size
                        print("  " + "original total size: " + str(sum_original_size))
                        print("  " + "sum of compressed sizes: " + str(sum_compress_size))
                        print("  " + "zip file size: " + str(zf_size.stat().st_size))
                        print("  " + "compression %: " + str( round(100*(sum_original_size)/(zf_size.stat().st_size), 1)) + " %")
                        print("  " + "overhead: " + str((zf_size.stat().st_size) - (sum_compress_size) ))
                        print()


# file1.txt (size: 124, compressed size: 97, compression %: 78.2 %)

zipInformation('words.zip', 'files.zip')