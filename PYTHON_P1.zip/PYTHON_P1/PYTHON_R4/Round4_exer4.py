# Sudoku with custom exceptions ---Done

class SudokuException(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def __str__(self):
        if (self.message == ""):
            return "[SudokuException]"
        else:
            return "[SudokuException] " + self.message


class SudokuTypeError(SudokuException):
    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def __str__(self):
        if (self.message == ""):
            return "[SudokuTypeError]"
        else:
            return "[SudokuTypeError] " + self.message


class SudokuValueError(SudokuException):
    def __init__(self, value):

        self.value = value
        if (str(value).isdigit()):
            super().__init__(message="The number " + value + " is not legal in Sudoku")
        else:
            super().__init__(message="The character " + value + " does not represent a digit")

    def __str__(self):
        if (self.message == ""):
            return "[SudokuValueError]"
        else:
            return "[SudokuValueError] " + self.message


# SudokuValueError(c)
def printSudoku(parameter):
    if type(parameter) != str:
        msg = "Illegal type" + " " + str(type(parameter))
        raise SudokuTypeError(msg)
    if len(parameter) != 81:
        msg = "Illegal length" + " " + str(len(parameter)) + " != 81"
        raise SudokuTypeError(msg)
    if (type(parameter) == str and len(parameter) == 81):
        for x in parameter:
            if x not in ["1", "2", "3", "4", "5", "6", "7", "8", "9"]:
                msg = str(x)
                raise SudokuValueError(msg)
            else:
                pass
    if (type(parameter) == str and len(parameter) == 81):
        ch_list = []
        for ch in parameter:
            ch_list.append(ch)

        for k in range(3):  # created first structure and duplicate 3 times
            for i in range(37):  # i first line of # only
                print("#", end="")
            print("")
            for m in range(5):  # duplicate second line in code below 5 times
                for j in range(37):  # created second line and use range of 5 above to dupliace 5 times
                    if (j % 12 == 0):
                        print("#", end="")
                    elif (j % 4 == 0 and m % 2 == 0):
                        print("|", end="")
                    elif (j % 4 == 0 and m % 2 != 0):
                        print("+", end="")
                    elif (m % 2 != 0):
                        print("-", end="")
                    elif (j % 2 == 0):
                        # put the first character in the ch_list and remove the
                        # character from the list
                        print(ch_list[0], end="")
                        del ch_list[0]
                    else:
                        print(" ", end="")
                print("")

        for i in range(37):  # last line of # only
            print("#", end="")
        print()
