# Pay Calculator ---Done by the teacher

import json
from sys import argv
from collections import defaultdict
from datetime import datetime

with open(argv[1]) as infile:
    jsondata = json.load(infile)
# print(jsondata)

workerIdMap = {}
for worker in jsondata["workers"]:
    workerIdMap[worker["id"]] = worker
# print(workerIdMap)

shiftMap = defaultdict(list)
for checkins in jsondata["checked in"] + jsondata["checked out"]:
    shiftMap[checkins["worker id"]].append(checkins["time"])
# print(shiftMap)

for workerId in shiftMap:
    wage = workerIdMap[workerId]["hourly wage"]
    totalPay = 0.0
    totalHours = 0
    times = [datetime.strptime(t, "%Y-%m-%dT%H:%M:%S") for t in sorted(shiftMap[workerId])]
    for i in range(1, len(times), 2):
        hours = ((times[i] - times[ i -1]).total_seconds() / 3600)
        totalHours += hours
        totalPay += hours * wage

    workerIdMap[workerId]["totalPay"] = totalPay
    workerIdMap[workerId]["hours"] = totalHours
# print(times)

for worker in sorted(workerIdMap.values(), key=lambda w :w["name"]):
    print(str(worker["id"]) + " " + worker["name"] + ": " + str(worker["hours"]), "hours, hourly wage",
          str(worker["hourly wage"]) + ", total pay", worker["totalPay"])

