# Python libraries for handling times and dates,
# special file types (e.g. csv, json and zip)

import datetime
import locale

dt2 = datetime.datetime(2017, 12, 24)
print(dt2)

print()
dt = datetime.datetime.now()
print(dt)

tdelta = dt2 - dt
print(tdelta, type(tdelta))
print(tdelta.total_seconds())

print()
print(dt.strftime("%Y-%b-%A"))
print(dt.strftime("%c"))

print()
print(locale.getlocale())

#locale.setlocale(locale.LC_CTIME, "fi_FI, utf-8")
import calendar

cal = calendar.calendar(2017)
print(cal)

# calendar with week number
print(dt.isocalendar())
print(dt.isocalendar()[1])
