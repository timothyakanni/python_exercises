# Word Length Zipper ---
from collections import defaultdict
import zipfile

def wordLengthZip(inputFilename, outputFilename):
    with open(inputFilename) as infile:
        d = defaultdict(list) # default dict initialize it value type from beginning
        # for example here, initialize its value as list
        for line in infile:
            for word in line.split():
                 d[len(word)].append(word) # d.setdefault(len(word), []).append(word)
        for m in sorted(d.keys()):
            print(sorted(d[m]), m)

        with zipfile.ZipFile(outputFilename, "w") as zf:
            for m in sorted(d.keys()):
                vale = ""
                if (len(sorted(d[m])) > 5):
                    for i in range(0, len(sorted(d[m])), 5):
                        vale += (" ".join(sorted(d[m])[i:i+5]))
                        vale += "\n"
                    zf.writestr("words_" + str(m) + ".txt", vale)

                else:
                    val = " ".join(sorted(d[m]))
                    val += "\n"
                    zf.writestr("words_" + str(m) + ".txt", val)


wordLengthZip("words2.txt", "words.zip")