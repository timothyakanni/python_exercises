# More about inheritance

class A:
    def __init__(self, name, value):
        print("init(A)")
        self.name = name
        self.value = value

# Here B inherit from A and has its own parameter value2
class B(A):
    def __init__(self, name, value, value2):
        super().__init__(name, value)
        print("init(B)")
        self.value2 = value2

# Here C also inherit from A and has its own parameter value3
class C(A):
    def __init__(self, name, value, value3):
        super().__init__(name, value)
        print("init(C)")
        self.value3 = str(value3)

class D(B, C):
    def __init__(self, name, value, value3, value4):
        super().__init__(name, value, value3)
        print("init(D)")
        self.value4 = str(value4)

#calling of object from classses

a = A("a", 10)
print()
b = B("b", 20, 5.75)
print()
c = C("c", 30, "a string")
print()
#d = D("d", 10, 10, 2.56)