import sys

# fileEncoding = "utf-8"
# if len(sys.argv) > 2:
#     fileEncoding = sys.argv[2]


def filterFun(x):
    return (len(x) == 2) and x[1].strip().isdecimal()


# print(sys.argv)
# if (len(sys.argv) < 2):
#     print("Give a file name as the command line parameter")
#     sys.exit("hhhh")

data = []
with open("vaaliliitot.csv", "r", encoding="iso-8859-1") as infile:
    for line in infile:
        data.append(line.split(";", 1))

print(data)
data = list(map(lambda x: [x[0], int(x[1])], filter(filterFun, data)))

data = list(map(lambda x: [x[0].strip("").split("/"), x[1]], data))

data = list(map(lambda x: [list(map(lambda y: y.strip(), x[0])), x[1]], data))

partyVotes = {}
for d in data:
    if len(d[0]) == 2:
        party = d[0][0]
        if party in partyVotes:
            partyVotes[party] += d[1]
        else:
            partyVotes[party] = d[1]


print(data)

with open("result,txt", "a") as outfile:
    print(partyVotes, file=outfile)
