
def divBy3or5or7(n):
    result = []
    for i in range(n+1):
        if(i%3) == 0 or (i%5) == 0 or (i%7)== 0:
            result.append(i)
    return result

for i in divBy3or5or7(50):
    print("", i, end="")
print()

#algorithm analysis: efficiently #yield keyword
def divBy3or5or7_(n):
    for i in range(n+1):
        if(i%3) == 0 or (i%5) == 0 or (i%7)== 0:
            yield i

for i in divBy3or5or7_(50):
    print("", i, end="")
print()

print(list(range(10)))

#define self range
def ownRange(start, stop, step):
    i = start
    while i < stop:
        yield i
        i += step

print(list(ownRange(1, 10, 1)))
