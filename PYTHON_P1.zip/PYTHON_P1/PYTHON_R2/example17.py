line = input()
data = []
while line:
    data.append(line)
    line = input()
print(data)

def dataCamp(d):
    return[len(d), d]

data = sorted(data, key=dataCamp)
print(data)

#Similarly
data = sorted(data, key=lambda d: [len(d), d])
print(data)



