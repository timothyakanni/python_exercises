

valmap = {}
for i in range(100):
    mod5 = i%5
    try:
        valmap[mod5].append(i)
    except KeyError:
        valmap[mod5] = [i]

    # Alternatively
    if mod5 in valmap:
        valmap[mod5].append(i)
    else:
        valmap[mod5] = [i]

print(valmap)

print(valmap.keys())

# items method of dictionary returns tuple
# with key parameter and list as value inside list
print(valmap.items())

