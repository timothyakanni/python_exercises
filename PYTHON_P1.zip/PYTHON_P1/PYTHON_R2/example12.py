# The syntax of a Python function definition:
# def functionName(parameters):
#   function body
#   whose statements are indented
#
# Note that return type is not defined explicitly. The function may
# or may not return a variable of any type.
def trans(d):
  return abs(int(d)) # Return the absolute value of d converted to int

# This function transforms string s into a list [len(s), s]
def lenApp(s):
  return [len(s), s]

# A helper function that picks out the second item from list v
def takeSecond(v):
  return v[1]

# In the lecture this program received the contents of the lecture 3 example
# file "data.txt": you may try to execute "python example12.py < data.txt"
line = input()
data = []
while line:
  data.append(line)
  line = input()
print(data)

# An example of how Python by default compares lists: two lists
# x and y are compared by comparing the values x[i] and y[i] for
# i = 0, 1, ... until a differing index is found (and that defines
# the comparison result) or both lists end (and they are deemed to
# be equal)
# This enables to e.g. define multiple sorting criteria by
# transforming the list items into sublists that hold the
# values on which the sorting criteria are based on. Here lenApp
# transforms each string s in data into a sublist [len(s), s]. When
# the list of these transformed values (sublists) is sorted, the
# sorting is primarily based on len(s) and secondarily on s itself
# (the alphabetical ordering).gfg
# The result is then again transformed back to a form that contains
# only the strings s: the function takeSecond transforms a sublist
# [len(s), s] into the string s.
# The final result is wrapped inside a list-constructor because
# map returns an iterable sequence (which is not yet a list).
data = list(map(takeSecond, sorted(map(lenApp, data))))
print(data)


# The sorted function also accepts an optional boolean parameter
# reverse that tells whether the values should be sorted into
# descending order.
data = map(trans, data)
data = sorted(data, reverse=True)
print(data)


# This ownMap-function is similar to Python's
# built-in map-function
def ownMap(some_function, some_list):
  result = []
  for val in some_list:
    result.append(some_function(val))
  return result

# The result below is same as if we would have done map(trans, data)
data = ownMap(trans, data)
data = sorted(data)
print(data)