# here we are importing argv from sys
from sys import argv

valmap = {}
i = 0
for arg in argv:
    if arg in valmap:
        valmap[arg].append(i)
    else:
        valmap[arg] = [i]
    i +=1

# this is getting the keys in dictionary
for key in valmap.keys():
    print("valmap[" + str(key) + "]:", valmap[key])


# dict {[]:hdhdh, []: hghgs}
# list []
# tuple ()
# set ()

