
#global and local variable analysis
number = 99

def doSomething():
    #refering to global variable using global
    global number
    number = 100
    print("Number is now", number)

print("Number: ", number)
doSomething()
print("Number: ", number)