# Soduke part 2 ---- Done

import sys
def checkSudoku(filename):
  grid = []
  with open(filename) as infile:
    for line in infile:
      parts = line.split()
      if len(parts) > 9:
        grid.append([int(parts[i]) for i in range(1,18,2)])

  badRows = []
  for row in range(9):
    if len({grid[row][col] for col in range(9)}) != 9:
      badRows.append(str(row + 1))
  badCols = []
  for col in range(9):
    if len({grid[row][col] for row in range(9)}) != 9:
      badCols.append(str(col + 1))
  badSubgrids = []
  for subRow in range(3):
    for subCol in range(3):
      if len({grid[row][col] for row in range(3*subRow, 3*(subRow+1))
        for col in range(3*subCol, 3*(subCol + 1))}) != 9:
          badSubgrids.append(str([subRow + 1, subCol + 1]))
  if badRows or badCols or badSubgrids:
    if badRows:
      print("Illegal rows:", " ".join(badRows))
    if badCols:
      print("Illegal columns:", " ".join(badCols))
    if badSubgrids:
      print("Illegal subgrids:", " ".join(badSubgrids))
  else:
    print("The sudoku solution is legal")

#Add your checkSudoku function definition above
#checkSudoku("Round2_exer2.py")
checkSudoku(sys.argv[1])