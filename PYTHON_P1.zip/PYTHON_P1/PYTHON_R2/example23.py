# here we work on set

#argvset = set()

# set discard duplicate item in the set
# add() can be used with set
# its advisable to use set to check for unique item
lst = [i for i in range(10)]
print(lst)

# for dict
valmap = {i: "value" + str(i) for i in range(10)}
print(valmap)